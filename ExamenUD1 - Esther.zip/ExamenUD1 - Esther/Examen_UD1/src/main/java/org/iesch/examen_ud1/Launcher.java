package org.iesch.examen_ud1;

import javafx.application.Application;

public class Launcher {
    public static void main(String[] args) {
        Application.launch(HelloApplication.class,args);
    }
}